from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^maps/farm/$', views.farm,name='farm'),
	url(r'^maps/house/$', views.house,name='house'),
	url(r'^house/$', views.house,name='house1'),
	url(r'^farm/$', views.farm,name='farm1'),
	url(r'^well/$', views.well,name='well1'),
	url(r'^maps/well/$', views.well,name='well'),
	url(r'^piechart/$', views.piechart,name='piechart'),
	url(r'^contact/$', views.contact,name='contact'),
	url(r'^3d/$', views.d3,name='3d'),
	url(r'^maps/$', views.maps,name='maps'),
	url(r'^$', views.index,name='index'),
]
